package com.app.reservas.repository.crudRepository;

import com.app.reservas.entities.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository<Category, Integer> { }
