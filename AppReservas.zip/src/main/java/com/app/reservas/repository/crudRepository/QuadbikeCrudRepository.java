package com.app.reservas.repository.crudRepository;

import com.app.reservas.entities.Quadbike;
import org.springframework.data.repository.CrudRepository;

public interface QuadbikeCrudRepository extends CrudRepository<Quadbike, Integer> { }
